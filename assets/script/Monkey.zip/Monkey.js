cc.Class({
    extends: cc.Component,

    properties: {
    },

    onLoad() {
        // 猴子的动画和行为可以在这里添加
        
    }
});