var soundlist = {
    hall_back_music : 'bgm01.mp3',
    table_back_music : 'bgm02.mp3',
    hall_click_sound : 'anniudianji.mp3',
};

module.exports = soundlist;


